import { Component, OnInit, HostListener } from '@angular/core';
import { Router } from '@angular/router';

@Component({
  selector: 'app-facilities',
  templateUrl: './facilities.component.html',
  styleUrls: ['./facilities.component.css']
})
export class FacilitiesComponent implements OnInit {
  facilitiesData = [
    { department: "Cardiology", description: "Expert care for your heart and vascular health." },
    { department: "Dermatology", description: "Advanced treatments for skin and hair issues." },
    { department: "Paediatrics", description: "Comprehensive healthcare for your little ones." },
    { department: "Orthopaedics", description: "Specialized care for bones, joints, and muscles." },
  ];
  index = 0;
  batch = 4;

  constructor(private router: Router) {}

  ngOnInit() {
    this.loadCards();
  }

  loadCards() {
    const end = Math.min(this.index + this.batch, this.facilitiesData.length);
    for (let i = this.index; i < end; i++) {
      const card = this.facilitiesData[i];
      // Logic to display card
    }
    this.index = end;
  }

  @HostListener('window:scroll', [])
  onScroll(): void {
    if ((window.innerHeight + window.scrollY) >= document.body.offsetHeight - 5) {
      this.loadCards();
    }
  }

  navigateTo(department: string) {
    this.router.navigate(['/book-appointment'], { queryParams: { department } });
  }
}
