import { Component } from '@angular/core';

@Component({
  selector: 'app-add-admin',
  templateUrl: './add-admin.component.html',
  styleUrls: ['./add-admin.component.css']
})
export class AddAdminComponent {
  username: string = '';
  password: string = '';
  confirmPassword: string = '';
  usernameExists: boolean = false;
  hardcodedUsernames: string[] = ['admin1', 'admin2', 'admin3'];

  addAdmin(event: Event) {
    event.preventDefault();
    if (!this.validateUsername()) {
      return alert("Please fill the username field correctly.");
    }
    if (!this.validatePassword()) {
      return alert("Please fill the password field correctly.");
    }
    if (!this.validateConfirmPassword()) {
      return alert("Passwords do not match.");
    }

    const adminList = JSON.parse(localStorage.getItem("adminList") || '[]');
    adminList.push({ username: this.username, password: this.password });
    localStorage.setItem("adminList", JSON.stringify(adminList));

    alert("New admin added successfully!");
    this.resetForm();
  }

  validateUsername(): boolean {
    const adminList = JSON.parse(localStorage.getItem("adminList") || '[]');
    this.usernameExists = adminList.some((admin: any) => admin.username === this.username.trim()) || this.hardcodedUsernames.includes(this.username.trim());
    return this.username.trim().length >= 4 && !this.usernameExists;
  }

  validatePassword(): boolean {
    const password = this.password.trim();
    return password.length >= 8 &&
           /[a-z]/.test(password) &&
           /[A-Z]/.test(password) &&
           /\d/.test(password) &&
           /[!@#$%^&*(),.?":{}|<>]/.test(password) &&
           !/\s/.test(password);
  }

  validateConfirmPassword(): boolean {
    return this.confirmPassword.trim() === this.password.trim();
  }

  resetForm() {
    this.username = '';
    this.password = '';
    this.confirmPassword = '';
    this.usernameExists = false;
  }
}
