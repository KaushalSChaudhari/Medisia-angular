import { Component } from '@angular/core';
import { FormBuilder, FormGroup, Validators } from '@angular/forms';

@Component({
  selector: 'app-add-patient',
  templateUrl: './add-patient.component.html',
  styleUrls: ['./add-patient.component.css']
})
export class AddPatientComponent {
  private static readonly NAME_PATTERN = '^[A-Za-z]+$';
  addPatientForm: FormGroup;
  doctors = {
    "11111111": "Dr. Sheena Murthy",
    "22222222": "Dr. Abdul Singh",
    "33333333": "Dr. Priya Shah",
    "44444444": "Dr. Ravi Kumar",
  };

  constructor(private fb: FormBuilder) {
    this.addPatientForm = this.fb.group({
      firstName: ['', [Validators.required, Validators.minLength(3), Validators.pattern(AddPatientComponent.NAME_PATTERN)]],
      lastName: ['', [Validators.required, Validators.minLength(3), Validators.pattern(AddPatientComponent.NAME_PATTERN)]],
      email: ['', [Validators.required, Validators.email]],
      mobile: ['', [Validators.required, Validators.pattern('^[0-9]{10}$')]],
      gender: ['', Validators.required],
      city: ['', Validators.required],
      doctorId: ['', [Validators.required, Validators.pattern('^[0-9]{8}$')]],
      address: ['', [Validators.required, Validators.minLength(2)]],
      bloodGroup: ['', Validators.required],
      weight: ['', [Validators.required, Validators.min(1), Validators.max(500)]],
      height: ['', [Validators.required, Validators.min(1), Validators.max(300)]],
      bill: [0, [Validators.required, Validators.min(0)]]
    });
  }

  get doctorName() {
    const doctorId: keyof typeof this.doctors = this.addPatientForm.get('doctorId')?.value;
    return this.doctors[doctorId] || 'Invalid ID';
  }

  addPatient() {
    if (this.addPatientForm.invalid) {
      alert('Please fill out the form correctly.');
      return;
    }

    const patientId = Math.floor(1000000 + Math.random() * 9000000); // Generate 7-digit PID
    const formValues = this.addPatientForm.value;
    alert(`New Patient ${formValues.firstName} ${formValues.lastName} added successfully with Username: ${formValues.username}, Patient ID (PID): ${patientId}`);

    const newPatient = {
      ...formValues,
      doctorName: this.doctorName,
      patientId
    };

    // Save patient details in localStorage as a list of patients
    let patients = JSON.parse(localStorage.getItem('patients') || '[]');
    patients.push(newPatient);
    localStorage.setItem('patients', JSON.stringify(patients));

    console.log('Patient details added successfully.');
    
  }
}
