import { Component } from '@angular/core';

@Component({
  selector: 'app-contact-us',
  templateUrl: './contact-us.component.html',
  styleUrls: ['./contact-us.component.css']
})
export class ContactUsComponent {
  // ...existing code...

  handleFormSubmit(event: Event) {
    event.preventDefault();

    const name = (document.getElementById('name') as HTMLInputElement).value.trim();
    const email = (document.getElementById('email') as HTMLInputElement).value.trim();
    const message = (document.getElementById('message') as HTMLTextAreaElement).value.trim();
    const formMessage = document.getElementById('formMessage') as HTMLParagraphElement;

    if (!name || name.length < 3) {
        formMessage.textContent = "Please enter a valid name.";
        formMessage.style.color = "red";
        return;
    }

    if (!/^[^\s@]+@[^\s@]+\.[^\s@]+$/.test(email)) {
        formMessage.textContent = "Please enter a valid email address.";
        formMessage.style.color = "red";
        return;
    }

    if (!message || message.length < 5) {
        formMessage.textContent = "Please enter a detailed message.";
        formMessage.style.color = "red";
        return;
    }

    formMessage.textContent = "Thank you for reaching out! We will get back to you soon.";
    formMessage.style.color = "green";

    // Clear form
    (document.getElementById('contactForm') as HTMLFormElement).reset();
  }
}
