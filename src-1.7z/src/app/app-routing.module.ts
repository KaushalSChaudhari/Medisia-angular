import { NgModule } from '@angular/core';
import { RouterModule, Routes } from '@angular/router';
import { FooterComponent } from './shared/footer/footer.component';
import { AdminHeaderComponent } from './shared/admin-header/admin-header.component';
import { UserHeaderComponent } from './shared/user-header/user-header.component';
import { IndexComponent } from './index/index.component';
import { UserDashboardComponent } from './components/user-dashboard/user-dashboard.component'; 
import { BookAppointmentComponent } from './components/book-appointment/book-appointment.component'; 
import { AdminDashboardComponent } from './components/admin-dashboard/admin-dashboard.component'; 
import { AddPatientComponent } from './components/add-patient/add-patient.component'; 
import { EditPatientComponent } from './components/edit-patient/edit-patient.component'; 
import { SearchPatientComponent } from './components/search-patient/search-patient.component'; 
import { ViewPatientComponent } from './components/view-patient/view-patient.component'; 
import { DeletePatientComponent } from './components/delete-patient/delete-patient.component'; 
import { AddAdminComponent } from './components/add-admin/add-admin.component'; 
import { ComplaintsComponent } from './components/complaints/complaints.component'; 
import { AppointmentsComponent } from './components/appointments/appointments.component'; 
import { SignupComponent } from './components/signup/signup.component'; 
import { ContactUsComponent } from './components/contact-us/contact-us.component'; 
import { FacilitiesComponent } from './components/facilities/facilities.component'; 


const routes: Routes = [
  { path: '', component: IndexComponent },
  { path: 'footer', component: FooterComponent },
  { path: 'admin-header', component: AdminHeaderComponent },
  { path: 'user-header', component: UserHeaderComponent },
  { path: 'book-appointment', component: BookAppointmentComponent },
  { path: 'user-dashboard', component: UserDashboardComponent },
  { path: 'admin-dashboard', component: AdminDashboardComponent },
  { path: 'add-patient', component: AddPatientComponent },
  { path: 'edit-patient', component: EditPatientComponent },
  { path: 'search-patient', component: SearchPatientComponent },
  { path: 'view-patient', component: ViewPatientComponent },
  { path: 'delete-patient', component: DeletePatientComponent },
  { path: 'add-admin', component: AddAdminComponent },
  { path: 'complaints', component: ComplaintsComponent },
  { path: 'appointments', component: AppointmentsComponent },
  { path: 'signup', component: SignupComponent },
  { path: 'contact-us', component: ContactUsComponent },
  { path: 'facilities', component: FacilitiesComponent }



  // other routes...
];

@NgModule({
  imports: [RouterModule.forRoot(routes)],
  exports: [RouterModule]
})
export class AppRoutingModule { }
