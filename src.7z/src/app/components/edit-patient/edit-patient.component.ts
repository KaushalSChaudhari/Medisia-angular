import { Component } from '@angular/core';

@Component({
  selector: 'app-edit-patient',
  templateUrl: './edit-patient.component.html',
  styleUrls: ['./edit-patient.component.css']
})
export class EditPatientComponent {
  patients: { patientId: number; firstName: string; mobile: string; }[] = [
    { patientId: 1111111, firstName: "Siddhant", mobile: "9876543210" },
    { patientId: 2222222, firstName: "Prathamesh", mobile: "9988776655" },
    { patientId: 333333, firstName: "Kaushal", mobile: "9123456789" },
    { patientId: 4444444, firstName: "Prajakta", mobile: "9345678123" },
    { patientId: 5555555, firstName: "Shreya", mobile: "9456123789" },
    { patientId: 6666666, firstName: "Rahul", mobile: "9234567890" },
    { patientId: 7777777, firstName: "Riya", mobile: "9876123450" }
    // Add more patients as needed
  ];
  searchInput: string = '';
  selectedPatient: any = null;

  fetchPatientById() {
    const patient = this.patients.find(p => p.patientId === parseInt(this.searchInput));
    if (patient) {
      this.selectedPatient = patient;
    } else {
      this.selectedPatient = null;
    }
  }

  updatePatientDetails() {
    if (this.selectedPatient) {
      // Validate form fields
      if (!/^\d{10}$/.test(this.selectedPatient.mobile)) {
        alert("Invalid Mobile Number");
        return;
      }

      alert(`Details updated successfully for Patient ${this.selectedPatient.firstName} PID ${this.selectedPatient.patientId}`);
    }
  }
}
