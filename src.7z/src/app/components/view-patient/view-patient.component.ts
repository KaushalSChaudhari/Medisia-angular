import { Component, OnInit } from '@angular/core';

interface Patient {
  patientId: number;
  firstName: string;
  lastName: string;
  email: string;
  mobile: string;
  gender: string;
  city: string;
  doctor: string;
  bloodGroup: string;
  weight: string;
  height: string;
  bill: string;
}

@Component({
  selector: 'app-view-patient',
  templateUrl: './view-patient.component.html',
  styleUrls: ['./view-patient.component.css']
})
export class ViewPatientComponent implements OnInit {
  patients: Patient[] = [];
  currentPage = 1;
  rowsPerPage = 5;

  ngOnInit() {
    this.fetchPatients();
  }

  fetchPatients() {
    this.patients = [
      { 
        patientId: 1111111, 
        firstName: "Siddhant", 
        lastName: "Chandankhede", 
        email: "siddhant@example.com", 
        mobile: "9876543210", 
        gender: "Male", 
        city: "Mumbai", 
        doctor: "Dr. Sheena", 
        bloodGroup: "O+", 
        weight: "70", 
        height: "170", 
        bill: "500" 
      },
      { 
        patientId: 2222222, 
        firstName: "Prathamesh", 
        lastName: "Kasar", 
        email: "prathamesh@example.com", 
        mobile: "9988776655", 
        gender: "Male", 
        city: "Pune", 
        doctor: "Dr. Abdul", 
        bloodGroup: "B+", 
        weight: "75", 
        height: "175", 
        bill: "3000" 
      },
      { 
        patientId: 333333, 
        firstName: "Kaushal", 
        lastName: "Chaudhari", 
        email: "kaushal@example.com", 
        mobile: "9123456789", 
        gender: "Male", 
        city: "Nashik", 
        doctor: "Dr. Kumar", 
        bloodGroup: "A-", 
        weight: "68", 
        height: "168", 
        bill: "4500" 
      },
      { 
        patientId: 4444444, 
        firstName: "Prajakta", 
        lastName: "Wankhede", 
        email: "prajakta@example.com", 
        mobile: "9345678123", 
        gender: "Female", 
        city: "Nagpur", 
        doctor: "Dr. Ramesh", 
        bloodGroup: "AB+", 
        weight: "60", 
        height: "160", 
        bill: "4000" 
      },
      { 
        patientId: 5555555, 
        firstName: "Shreya", 
        lastName: "Deokar", 
        email: "shreya@example.com", 
        mobile: "9456123789", 
        gender: "Female", 
        city: "Aurangabad", 
        doctor: "Dr. Priya", 
        bloodGroup: "B-", 
        weight: "55", 
        height: "155", 
        bill: "3500" 
      },
      { 
        patientId: 6666666, 
        firstName: "Rahul", 
        lastName: "Deshmukh", 
        email: "rahul@example.com", 
        mobile: "9234567890", 
        gender: "Male", 
        city: "Hyderabad", 
        doctor: "Dr. Nikhil", 
        bloodGroup: "O-", 
        weight: "72", 
        height: "172", 
        bill: "3200" 
      },
      { 
        patientId: 7777777, 
        firstName: "Riya", 
        lastName: "Patil", 
        email: "riya@example.com", 
        mobile: "9876123450", 
        gender: "Female", 
        city: "Chennai", 
        doctor: "Dr. Rekha", 
        bloodGroup: "A+", 
        weight: "58", 
        height: "158", 
        bill: "2800" 
      }
      // Add more patients...
    ];
    this.displayPatients();
  }

  displayPatients() {
    const start = (this.currentPage - 1) * this.rowsPerPage;
    const end = start + this.rowsPerPage;
    return this.patients.slice(start, end);
  }

  updatePageInfo() {
    return `Page ${this.currentPage} of ${Math.ceil(this.patients.length / this.rowsPerPage)}`;
  }

  prevPage() {
    if (this.currentPage > 1) {
      this.currentPage--;
    }
  }

  nextPage() {
    if (this.currentPage < Math.ceil(this.patients.length / this.rowsPerPage)) {
      this.currentPage++;
    }
  }
}
