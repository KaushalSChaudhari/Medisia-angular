import { Component } from '@angular/core';
import { FormBuilder, FormGroup, Validators } from '@angular/forms';

@Component({
  selector: 'app-signup',
  templateUrl: './signup.component.html',
  styleUrls: ['./signup.component.css']
})
export class SignupComponent {
  signupForm: FormGroup;

  constructor(private fb: FormBuilder) {
    this.signupForm = this.fb.group({
      username: ['', [Validators.required, Validators.minLength(3), Validators.pattern(/^\w+$/)]],
      firstName: ['', [Validators.required, Validators.minLength(2), Validators.pattern(/^[A-Za-z]+$/)]],
      lastName: ['', [Validators.required, Validators.minLength(2), Validators.pattern(/^[A-Za-z]+$/)]],
      email: ['', [Validators.required, Validators.email]],
      mobile: ['', [Validators.required, Validators.pattern(/^\d{10}$/)]],
      gender: ['', Validators.required],
      city: ['', Validators.required],
      bloodGroup: ['', Validators.required],
      weight: ['', [Validators.required, Validators.min(1), Validators.max(300)]],
      height: ['', [Validators.required, Validators.min(1), Validators.max(300)]],
      password: ['', [Validators.required, Validators.minLength(8), Validators.pattern(/[A-Za-z]/), Validators.pattern(/\d/)]],
      confirmPassword: ['', Validators.required]
    }, { validator: this.passwordMatchValidator });
  }

  passwordMatchValidator(form: FormGroup) {
    return form.get('password')?.value === form.get('confirmPassword')?.value ? null : { mismatch: true };
  }

  onSubmit() {
    if (this.signupForm.valid) {
      alert('Signup successful!');
    } else {
      alert('Please fill out all fields correctly.');
    }
  }
}
