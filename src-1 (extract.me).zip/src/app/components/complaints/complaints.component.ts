import { Component, OnInit } from '@angular/core';

@Component({
  selector: 'app-complaints',
  templateUrl: './complaints.component.html',
  styleUrls: ['./complaints.component.css']
})
export class ComplaintsComponent implements OnInit {
  complaints: Complaint[] = [];
  filteredComplaints: Complaint[] = [];

  ngOnInit() {
    this.loadComplaints();
  }

  loadComplaints() {
    // Load complaints from a service or local storage
    this.complaints = [
      // Example data
      { id: 1, name: 'John Doe', contact: '1234567890', type: 'Service', description: 'Issue with service', date: new Date(), status: 'Pending', subject: 'Service Issue', message: 'There is an issue with the service.' }
    ];
    this.filteredComplaints = this.complaints;
  }

  registerComplaint(event: Event) {
    event.preventDefault();
    // Logic to register a new complaint
  }

  filterComplaints(searchTerm: string) {
    this.filteredComplaints = this.complaints.filter(complaint => 
      complaint.name.toLowerCase().includes(searchTerm.toLowerCase()) ||
      complaint.type.toLowerCase().includes(searchTerm.toLowerCase()) ||
      complaint.description.toLowerCase().includes(searchTerm.toLowerCase())
    );
  }

  deleteComplaint(id: number) {
    this.complaints = this.complaints.filter(complaint => complaint.id !== id);
    this.filteredComplaints = this.filteredComplaints.filter(complaint => complaint.id !== id);
  }
}

interface Complaint {
  id: number;
  name: string;
  contact: string;
  type: string;
  description: string;
  date: Date;
  status: string;
  subject: string;
  message: string;
}
