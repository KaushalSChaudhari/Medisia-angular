import { Component, OnInit } from '@angular/core';

@Component({
  selector: 'app-book-appointment',
  templateUrl: './book-appointment.component.html',
  styleUrls: ['./book-appointment.component.css']
})
export class BookAppointmentComponent implements OnInit {
  doctors: { [key: string]: string[] } = {
    Cardiology: ["Dr. Om", "Dr. Shiv"],
    Dermatology: ["Dr. Manish", "Dr. Patel"],
    Paediatrics: ["Dr. Aman", "Dr. Chetan"],
    Orthopaedics: ["Dr. Prasad", "Dr. Tushar"],
  };
  department: string = '';
  doctor: string = '';
  date: string = '';
  time: string = '';
  bill: number = 0;
  confirmationMessage: string = '';
  timeSlots: string[] = [];
  filteredDoctors: string[] = [];

  ngOnInit() {
    this.validateDate();
    this.generateTimeSlots();
  }

  filterDoctors() {
    if (this.department && this.doctors[this.department]) {
      this.filteredDoctors = this.doctors[this.department];
      this.doctor = '';
    } else {
      this.filteredDoctors = [];
    }
    this.updateBill();
  }

  validateDate() {
    const today = new Date();
    today.setDate(today.getDate() + 1); // Set min date to tomorrow
    const minDate = today.toISOString().split("T")[0];
    const dateInput = document.getElementById("date") as HTMLInputElement;
    dateInput.min = minDate;
    this.updateBill();
  }

  generateTimeSlots() {
    for (let hour = 8; hour < 18; hour++) {
      for (let minutes = 0; minutes < 60; minutes += 30) {
        const time = `${hour.toString().padStart(2, '0')}:${minutes.toString().padStart(2, '0')}`;
        this.timeSlots.push(time);
      }
    }
  }

  updateBill() {
    if (this.department && this.doctor && this.date && this.time) {
      this.bill = 800; // Set the bill to ₹800
    } else {
      this.bill = 0; // Reset to ₹0 if any field is incomplete
    }
  }

  bookAppointment(event: Event) {
    event.preventDefault();
    if (this.department && this.doctor && this.date && this.time) {
      const patientId = Math.floor(Math.random() * 10000000); // Example patient ID
      this.confirmationMessage = `Appointment Successfully booked for PID ${patientId} with Doctor ${this.doctor} on ${this.date} at ${this.time}.`;
    } else {
      alert("Please fill all fields.");
    }
  }
}
