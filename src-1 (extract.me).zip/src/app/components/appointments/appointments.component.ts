import { Component, OnInit } from '@angular/core';

@Component({
  selector: 'app-appointments',
  templateUrl: './appointments.component.html',
  styleUrls: ['./appointments.component.css']
})
export class AppointmentsComponent implements OnInit {
  appointments = [
    { patientId: 1, patientName: 'John Doe', department: 'Cardiology', date: '2023-10-01', time: '10:00 AM', doctorName: 'Dr. Smith' },
    { patientId: 2, patientName: 'Jane Smith', department: 'Neurology', date: '2023-10-02', time: '11:00 AM', doctorName: 'Dr. Johnson' }
    // Add more appointments as needed
  ];

  constructor() { }

  ngOnInit(): void {
    // Fetch appointments from a service if needed
  }
}
