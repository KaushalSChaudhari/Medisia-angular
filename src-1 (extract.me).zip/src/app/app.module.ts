import { NgModule } from '@angular/core';
import { BrowserModule } from '@angular/platform-browser';
import { FormsModule, ReactiveFormsModule } from '@angular/forms'; // Import FormsModule and ReactiveFormsModule

import { AppRoutingModule } from './app-routing.module';
import { AppComponent } from './app.component';
import { AdminHeaderComponent } from './shared/admin-header/admin-header.component';
import { UserHeaderComponent } from './shared/user-header/user-header.component';
import { FooterComponent } from './shared/footer/footer.component';
import { AddPatientComponent } from './components/add-patient/add-patient.component';
import { IndexComponent } from './index/index.component';
import { BookAppointmentComponent } from './components/book-appointment/book-appointment.component';
import { UserDashboardComponent } from './components/user-dashboard/user-dashboard.component';
import { AdminDashboardComponent } from './components/admin-dashboard/admin-dashboard.component';
import { EditPatientComponent } from './components/edit-patient/edit-patient.component';
import { SearchPatientComponent } from './components/search-patient/search-patient.component';
import { ViewPatientComponent } from './components/view-patient/view-patient.component';
import { DeletePatientComponent } from './components/delete-patient/delete-patient.component';
import { AddAdminComponent } from './components/add-admin/add-admin.component';
import { ComplaintsComponent } from './components/complaints/complaints.component';
import { AppointmentsComponent } from './components/appointments/appointments.component';
import { SignupComponent } from './components/signup/signup.component';
import { ContactUsComponent } from './components/contact-us/contact-us.component';
import { FacilitiesComponent } from './components/facilities/facilities.component';

@NgModule({
  declarations: [
    AppComponent,
    AdminHeaderComponent,
    UserHeaderComponent,
    FooterComponent,
    AddPatientComponent,
    IndexComponent,
    BookAppointmentComponent,
    UserDashboardComponent,
    AdminDashboardComponent,
    EditPatientComponent,
    SearchPatientComponent,
    ViewPatientComponent,
    DeletePatientComponent,
    AddAdminComponent,
    ComplaintsComponent,
    AppointmentsComponent,
    SignupComponent,
    ContactUsComponent,
    FacilitiesComponent
  ],
  imports: [
    BrowserModule,
    AppRoutingModule,
    FormsModule, // Add FormsModule to imports array
    ReactiveFormsModule // Add ReactiveFormsModule to imports array
  ],
  providers: [],
  bootstrap: [AppComponent]
})
export class AppModule { }
