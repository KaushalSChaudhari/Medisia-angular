import { Component } from '@angular/core';
import { Router } from '@angular/router';

@Component({
  selector: 'app-index',
  templateUrl: './index.component.html',
  styleUrls: ['./index.component.css']
})
export class IndexComponent {
  username: string = '';
  password: string = '';
  userType: 'admin' | 'patient' = 'patient';

  constructor(private router: Router) {}

  login() {
    const users = {
      admin: { username: "admin123", password: "Admin@123" },
      patient: { username: "patient123", password: "Patient@123" },
    };

    const user = users[this.userType as 'admin' | 'patient'];

    if (user && user.username === this.username && user.password === this.password) {
      if (this.userType === "admin") {
        this.router.navigate(['/admin-dashboard']);
      } else {
        this.router.navigate(['/user-dashboard']);
      }
    } else {
      alert("Invalid Username or Password");
    }
  }
}
