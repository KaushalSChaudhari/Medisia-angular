import { Component } from '@angular/core';

@Component({
  selector: 'app-admin-header',
  templateUrl: './admin-header.component.html',
  styleUrls: ['./admin-header.component.css']
})
export class AdminHeaderComponent {
  toggleMenu() {
    const sideMenu = document.getElementById("sideMenu");
    sideMenu?.classList.add("active");
  }

  closeMenu() {
    const sideMenu = document.getElementById("sideMenu");
    sideMenu?.classList.remove("active");
  }

  navigateTo(page: string) {
    window.location.href = page;
  }

  logout() {
    alert("You have been logged out.");
    window.location.href = "/";
  }
}
